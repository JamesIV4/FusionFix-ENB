//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

FOR NEWBIES: This version (as others, btw) is not configured to look great, run fast
or something like that, read documentation! For lazy folks here is the link to presets
from over users:
http://www.gtaforums.com/index.php?act=ST&f=223&t=417918&st=0#entry1059353859



ENBSeries v0.163 graphic modification for GTA 4 

Added by request "SunDirection" vector to enbbloom.fx, enbeffect.fx, effect.txt
shaders. Fixed wrong ScreenSize parameter in enbeffect.fx.
Tweaked detailed shadows to fix (partially) artifacts of this effect. Changed
ssao code quality and performance, added new parameter SamplingPrecision.



WARNING! Standart of effect.txt file is changed to newest (like Skyrim mod), not hard
to modify that shader by any user, just download example effect.txt files from enbdev.com
and compare old and new versions.


For version 0.162:
Added detailed shadows effect. Fixed some artifacts.

For version 0.135:
Fixed minor bugs, increased stability, added edge antialiasing. Changed standart of
effect.txt shader file to newest, so it may require manual modification.
This version is still don't have new graphic effects and support patch 4, wait next
updates.

For version 0.127: Implemented GUI for editing enbseries.ini inside the game, to activate it press
buttons SHIFT and ENTER together. Fixed some known bugs from previous beta versions
which appears after changing core to newest version (for better performance).
This version is still don't have new graphic effects and support patch 4, wait next
updates.

For version 0.082: This is temporary version with some features disabled or working in wrong way.
Parameters ReflectionsForceHighPrecision and ReflectionsExtremePrecision not used any more.
Added soft particles effect, added palette texture support for enbeffect.fx (enbpalette.bmp).
Added new texture "texPalette" and "Timer" variable to effect.txt and enbeffect.fx files.
Restored color function from version 0.079. enbseries.ini is not configured.

For version 0.081 SORA: Adaptation of previous version to game patch 1.0.6.0 with limited number
of effects activated. If you wish to use full power of ENBSeries, install patch 1.0.4.0
For version 0.080 SORA: Added new parameter AntialiasingUpScale for better performance of antialiasing. Effect.txt
file is now able to post process multipass effects (included have blur, sharpening and color
shift effects applied at once). In the enbeffect.fx implemented two versions of hdr tonemapping,
also it's is possible to activate game color correction (open that file and read instructions)
like brightness, contrast, saturation. Changed method of blending light, color and shadow.
For version 0.079 SORA: Added support for loading of external shaders for clouds generation and bloom.
Implemented moon. To activate moon, place files enbmoon.tga and enbmoonbump.tga in to the game
folder (tga, png, bmp files are supported). enbmoon image file must be with alpha channel.
To change stars texture, copy enbstars.tga (png, bmp) in to the game folder.
To change clouds texture, copy enbclouds.tga (png, bmp) in to the game folder.
For version 0.078b: Fixed bugs with lighting and reflection, added code for sky and clouds
External texture of clouds may be used instead of ingame procedural generator,
just place file enbclouds.bmp in to the game folder.
For version 0.077b: added support of external effect file (effect.txt) and fixed bug of dirt on some cars
For version 0.077a: adopted to use with patch 1.0.0.3 and 1.0.0.4, previous
worked correctly only with patch 1.0.0.3. Visit enbdev.com for updates, documentation and effects.
This version was tested on NVidia cards only. Quality of shadows must to be set
to High or Very High.
This modification works incorrectly with modified game folder "common\shaders",
so leave it as in the original game patched to 1.0.0.3 or 1.0.0.4, overwise brightness
and over artifacts will appear. Also check out your videocard driver setting and
set them correctly as described in the documentation www.enbdev.com
Antialiasing produce some artifacts on ATI cards, i don't have it for testing,
so forget.


Here you may download user made presets or just to see nice screens
http://www.gtaforums.com/index.php?showtopic=417918


PROBLEMS SOLVING:
If some graphical artifacts (like too high brightness) are visible, restore original game
shaders folder "common\shaders". In many cases other types of graphic mods change this.




PARTIAL DESCRIPTION:
[ENGINE]
ForceDisplaySize=false - this parameter not used any more for antialiasing
ForceAntialiasing=false - turn on antialiasing
AntialiasingQuality=2 - quality of antialiasing, -1 is max, 2 is min. recommended 1 or 2, 0 or -1 for extremely fast videocards
AntialiasingUpScale - values in range from 0.25 till 1.0. Lower values increase performance, but makes blurry image

[SSAO_SSIL]
SamplingQuality=-1	this is new value (negative) mean extreme quality for high end videocards
SourceTexturesScale=0.5	if lower than 1, performance increased, but less detailed
SizeScale=1.0		size of texture, less means greater speed with lower quality
SamplingRange=1.0	if lower, then greater speed and more detatiled objects

[GLOBAL]
CyclicConfigReading=true read config every 5 second to make easier editing on the fly

[EFFECT]
UseOriginalPostProcessing=false if enabled, original game post processing is activated

[LIGHTSPRITE]
UseExternalTexture=true loads user defined textures for sprites of light
(enbspritelight.png, enbspritelight.bmp, enbspriteray.png, enbspriteray.bmp)


enbeffect.fx	shader of post processing (game and my code)




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SYSTEM REQUIREMENTS:
Videocard with support of Shader Model 3.0 or better. Videocards in the list below may fit:
GeForce 8xxx, 9xxx and higher;
Radeon 2xxx, 3xxx and higher.


INSTALLING:
Extract files from archive in to the game directory or where game execution file exist (.exe).

STARTING:
After game start the mod activated by default, to deactivate it use key combination (shift+f12 by default).


SETTING DESCRIPTION:

//UNDOCUMENTED YET



Key numbers (virtual key codes) available in key_codes.txt or key_codes.htm. In current version of the mod these lists of key codes are hex values, but mod works with decimal, i can't describe now how to convert them, may be later i'll do something.




//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
DONATE:
If on Your opinion ENBSeries project must continue to live or simply it was useful for yourself, i'll be grateful for sponsoring project (or donation).



http://enbdev.com
Copyright (c) 2007-2014 Vorontsov Boris (ENB developer)